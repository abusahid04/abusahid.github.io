import React, { useState, useEffect } from 'react';
import { motion, useScroll, useSpring } from 'framer-motion';
import { TypeAnimation } from 'react-type-animation';
import { 
  Moon, Sun, Menu, X, Mail, 
  ExternalLink, Download, Briefcase, GraduationCap, Trophy, 
  ChevronRight, MapPin, Calendar, Code, Smartphone, Database, PenTool, Code2,
  ArrowDownCircle, ArrowUpCircle, Layers
} from 'lucide-react';
import { FaGithub, FaLinkedin, FaInstagram } from 'react-icons/fa';
import Tilt from 'react-parallax-tilt';
import './App.css';

// --- DATA ---
const projects = [
  {
    id: 1,
    title: 'GPT Prompts',
    description: 'A platform for discovering, organizing, and sharing AI prompts with category management and an admin dashboard.',
    tags: ['PHP', 'MySQL', 'HTML', 'CSS', 'JavaScript'],
    icon: <Database className="w-6 h-6" />
  },
  {
    id: 2,
    title: 'Wallpaper Hub',
    description: 'A wallpaper website and Android application featuring HD, 4K, AMOLED, Gaming, Anime, and Nature wallpapers.',
    tags: ['PHP', 'MySQL', 'Android Studio'],
    icon: <Smartphone className="w-6 h-6" />
  },
  {
    id: 3,
    title: 'Password Saver',
    description: 'An offline Android application to securely store passwords using PIN protection.',
    tags: ['Java', 'XML', 'SharedPreferences'],
    icon: <Code className="w-6 h-6" />
  },
  {
    id: 4,
    title: 'Age Calculator',
    description: 'An Android application that calculates age, next birthday, and age statistics.',
    tags: ['Java', 'XML'],
    icon: <Calendar className="w-6 h-6" />
  },
  {
    id: 5,
    title: 'Tutor App (Concept)',
    description: 'An educational platform connecting students with private tutors, featuring profiles and dashboards.',
    tags: ['Figma', 'UI/UX Design'],
    icon: <PenTool className="w-6 h-6" />
  },
  {
    id: 6,
    title: 'Khoraghat Premier League (KPL)',
    description: 'A cricket tournament management website with player registration, auction system, and live updates.',
    tags: ['PHP', 'MySQL', 'HTML', 'CSS', 'JavaScript'],
    icon: <Trophy className="w-6 h-6" />
  }
];

const skills = [
  { name: 'Java', level: 85 },
  { name: 'JavaScript', level: 90 },
  { name: 'PHP', level: 80 },
  { name: 'HTML5 & CSS3', level: 95 },
  { name: 'Android Studio', level: 85 },
  { name: 'MySQL', level: 80 },
  { name: 'Firebase', level: 75 },
  { name: 'UI/UX Design', level: 70 }
];

const experiences = [
  'Android App Development',
  'Web Development',
  'UI/UX Design',
  'Database Design',
  'API Development',
  'Project Planning'
];

const achievements = [
  'Developed multiple Android applications.',
  'Built several responsive websites.',
  'Created admin dashboards using PHP & MySQL.',
  'Passionate about learning modern technologies and software development.'
];

// --- COMPONENTS ---

const Navbar = ({ theme, toggleTheme }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30, restDelta: 0.001 });

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = ['About', 'Education', 'Skills', 'Projects', 'Experience', 'Contact'];

  return (
    <>
      <motion.div className="progress-bar" style={{ scaleX }} />
      <nav className={`navbar ${scrolled ? 'scrolled glass-panel' : ''}`}>
        <div className="nav-content">
          <a href="#" className="nav-brand text-gradient">DevSahid.</a>
          
          <div className="nav-desktop">
            <ul className="nav-links">
              {navLinks.map(link => (
                <li key={link}><a href={`#${link.toLowerCase()}`}>{link}</a></li>
              ))}
            </ul>
            <button onClick={toggleTheme} className="theme-toggle">
              {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
            </button>
          </div>

          <div className="nav-mobile-btn">
            <button onClick={toggleTheme} className="theme-toggle mr-4">
              {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <button onClick={() => setIsOpen(!isOpen)}>
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, x: '100%' }} 
            animate={{ opacity: 1, x: 0 }} 
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'spring', stiffness: 200, damping: 25 }}
            className="nav-mobile-menu glass-panel"
          >
            <ul className="mobile-links-container">
              {navLinks.map((link, i) => (
                <motion.li 
                  key={link}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                >
                  <a href={`#${link.toLowerCase()}`} onClick={() => setIsOpen(false)}>{link}</a>
                </motion.li>
              ))}
            </ul>
          </motion.div>
        )}
      </nav>
    </>
  );
};

const Hero = () => {
  return (
    <section id="hero" className="hero-section cyber-border-bottom">
      <div className="marquee-container cyber-border-bottom">
        <div className="marquee-text">
          <span>SYSTEM OFFLINE • REBOOTING... • NEURAL LINK ESTABLISHED • SOFTWARE ENGINEER • </span>
          <span>SYSTEM OFFLINE • REBOOTING... • NEURAL LINK ESTABLISHED • SOFTWARE ENGINEER • </span>
        </div>
      </div>

      <motion.div 
        className="hero-content"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <div className="glitch-wrapper">
          <h1 className="hero-name-massive glitch" data-text="ABU SAHID.">ABU SAHID.</h1>
        </div>
        
        <div className="hero-grid-info">
          <div className="info-box cyber-border-right">
            <p className="label">SYS.ROLE</p>
            <div className="hero-roles">
              <TypeAnimation
                sequence={[
                  'Software Developer', 2000,
                  'Android Enthusiast', 2000,
                  'Web Developer', 2000,
                  'UI/UX Designer', 2000,
                ]}
                wrapper="span"
                speed={50}
                repeat={Infinity}
                className="typing-text"
              />
            </div>
          </div>
          <div className="info-box cyber-border-right">
            <p className="label">SYS.BIO</p>
            <p className="hero-desc">
              Passionate about technology, software development, and creating useful digital products that solve real-world problems.
            </p>
          </div>
          <div className="info-box hero-cta-box">
             <a href="#projects" className="btn btn-primary w-full text-center">
              View Projects
            </a>
            <a href="#" className="btn btn-outline w-full text-center mt-4">
              Download Resume
            </a>
          </div>
        </div>
        
        <div className="social-links mt-8 mb-16 cyber-box">
          <a href="https://github.com" target="_blank" rel="noreferrer"><FaGithub size={24} /></a>
          <a href="https://linkedin.com" target="_blank" rel="noreferrer"><FaLinkedin size={24} /></a>
          <a href="https://instagram.com" target="_blank" rel="noreferrer"><FaInstagram size={24} /></a>
          <a href="mailto:contact@example.com"><Mail size={24} /></a>
        </div>
      </motion.div>

      <motion.div 
        className="scroll-indicator"
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 1.5 }}
      >
        <ArrowDownCircle size={32} />
      </motion.div>
    </section>
  );
};

const About = () => (
  <section id="about" className="section">
    <h2 className="section-title">About Me</h2>
    <motion.div 
      className="about-content glass-panel"
      initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}
    >
      <p>
        Hi, I'm Abu Sahid, a first-year <strong>B.Tech</strong> student at Assam down town University (ADTU), Assam. 
        I am deeply passionate about technology, software development, web development, 
        Android app development, and UI/UX design.
      </p>
      <p className="mt-4">
        I thrive on creating useful digital products and enjoy learning new technologies. My goal is to build projects that bridge the gap 
        between complex problems and elegant software solutions.
      </p>
    </motion.div>
  </section>
);

const Education = () => (
  <section id="education" className="section">
    <h2 className="section-title">Education</h2>
    <div className="timeline">
      <motion.div className="timeline-item" initial={{ opacity: 0, x: -50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
        <div className="timeline-icon"><GraduationCap size={24} /></div>
        <div className="timeline-content glass-panel">
          <span className="timeline-date">2026 - 2030</span>
          <h3>Bachelor of Technology (B.Tech)</h3>
          <h4>Assam down town University (ADTU)</h4>
          <p className="flex items-center gap-2 mt-2 text-sm text-secondary"><MapPin size={16}/> Guwahati, Assam</p>
        </div>
      </motion.div>

      <motion.div className="timeline-item" initial={{ opacity: 0, x: -50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.2 }}>
        <div className="timeline-icon"><GraduationCap size={24} /></div>
        <div className="timeline-content glass-panel">
          <span className="timeline-date">2024 - 2026</span>
          <h3>Higher Secondary (Science)</h3>
          <h4>Rokakhata Higher Secondary School</h4>
        </div>
      </motion.div>
    </div>
  </section>
);

const Skills = () => (
  <section id="skills" className="section">
    <h2 className="section-title">Technical Skills</h2>
    <div className="skills-grid">
      {skills.map((skill, index) => (
        <motion.div 
          key={skill.name} 
          className="skill-item"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: index * 0.1 }}
        >
          <div className="skill-info">
            <span>{skill.name}</span>
            <span>{skill.level}%</span>
          </div>
          <div className="progress-bg">
            <motion.div 
              className="progress-bar-fill" 
              initial={{ width: 0 }}
              whileInView={{ width: `${skill.level}%` }}
              viewport={{ once: true }}
              transition={{ duration: 1, delay: 0.5 }}
            />
          </div>
        </motion.div>
      ))}
    </div>
  </section>
);

const Projects = () => (
  <section id="projects" className="section">
    <h2 className="section-title">Featured Projects</h2>
    <div className="projects-grid">
      {projects.map((project, index) => (
        <motion.div 
          key={project.id} 
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: index * 0.1 }}
        >
          <Tilt tiltMaxAngleX={5} tiltMaxAngleY={5} scale={1.02} transitionSpeed={2500} className="h-full">
            <div className="project-card glass-panel h-full relative group overflow-hidden">
              <div className="project-icon">{project.icon}</div>
              <h3>{project.title}</h3>
              <p>{project.description}</p>
              <div className="tags mt-auto pt-4">
                {project.tags.map(tag => (
                  <span key={tag} className="tag">{tag}</span>
                ))}
              </div>
              
              {/* Hover Links Overlay */}
              <div className="project-links-overlay">
                <a href="#" className="icon-link"><FaGithub size={20} /></a>
                <a href="#" className="icon-link"><ExternalLink size={20} /></a>
              </div>
            </div>
          </Tilt>
        </motion.div>
      ))}
    </div>
  </section>
);

const Experience = () => (
  <section id="experience" className="section">
    <div className="grid-2-cols">
      <div>
        <h2 className="section-title" style={{ textAlign: 'left', transform: 'none', left: '0' }}>Experience Areas</h2>
        <div className="exp-list">
          {experiences.map((exp, i) => (
            <motion.div key={i} className="exp-item glass-panel" initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i*0.1 }}>
              <Briefcase className="text-primary" size={20} />
              <span>{exp}</span>
            </motion.div>
          ))}
        </div>
      </div>
      <div>
        <h2 className="section-title" style={{ textAlign: 'left', transform: 'none', left: '0' }}>Key Achievements</h2>
        <div className="achievements-list">
          {achievements.map((ach, i) => (
            <motion.div key={i} className="ach-item" initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i*0.1 }}>
              <Trophy className="text-accent" size={24} style={{ flexShrink: 0 }}/>
              <p>{ach}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  </section>
);

const Contact = () => (
  <section id="contact" className="section">
    <h2 className="section-title">Get In Touch</h2>
    <div className="contact-wrapper glass-panel">
      <form className="contact-form" onSubmit={(e) => e.preventDefault()}>
        <div className="form-group">
          <label>Name</label>
          <input type="text" placeholder="Your Name" required />
        </div>
        <div className="form-group">
          <label>Email</label>
          <input type="email" placeholder="Your Email" required />
        </div>
        <div className="form-group">
          <label>Message</label>
          <textarea rows="5" placeholder="Your Message" required></textarea>
        </div>
        <button type="submit" className="btn btn-primary w-full">Send Message</button>
      </form>
    </div>
  </section>
);

const Footer = () => (
  <footer className="footer">
    <p>&copy; 2026 Abu Sahid. All Rights Reserved.</p>
  </footer>
);

const CustomCursor = () => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  
  useEffect(() => {
    const updateMouse = (e) => setMousePos({ x: e.clientX, y: e.clientY });
    window.addEventListener('mousemove', updateMouse);
    return () => window.removeEventListener('mousemove', updateMouse);
  }, []);

  return (
    <>
      <motion.div 
        className="cursor-dot"
        animate={{ x: mousePos.x, y: mousePos.y }}
        transition={{ type: "spring", stiffness: 1000, damping: 40, mass: 0.1 }}
      />
      <motion.div 
        className="cursor-ring"
        animate={{ x: mousePos.x, y: mousePos.y }}
        transition={{ type: "spring", stiffness: 200, damping: 30, mass: 0.5 }}
      />
    </>
  );
};

const BackToTop = () => {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const handleScroll = () => setShow(window.scrollY > 400);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.button 
      className="back-to-top"
      initial={{ opacity: 0, scale: 0 }}
      animate={{ opacity: show ? 1 : 0, scale: show ? 1 : 0 }}
      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
    >
      <ArrowUpCircle size={28} />
    </motion.button>
  );
}

const Services = () => (
  <section id="services" className="section">
    <h2 className="section-title">What I Do</h2>
    <div className="projects-grid">
      <motion.div className="project-card glass-panel text-center h-full flex flex-col" whileHover={{ y: -10 }}>
        <div className="project-icon" style={{ margin: '0 auto 1.5rem' }}><Smartphone className="w-8 h-8" /></div>
        <h3>Android App Dev</h3>
        <p>Building native and robust Android applications with Java, XML, and Firebase.</p>
      </motion.div>
      <motion.div className="project-card glass-panel text-center h-full flex flex-col" whileHover={{ y: -10 }}>
        <div className="project-icon" style={{ margin: '0 auto 1.5rem' }}><Layers className="w-8 h-8" /></div>
        <h3>Web Development</h3>
        <p>Creating responsive, dynamic websites using React, PHP, MySQL, and modern CSS.</p>
      </motion.div>
      <motion.div className="project-card glass-panel text-center h-full flex flex-col" whileHover={{ y: -10 }}>
        <div className="project-icon" style={{ margin: '0 auto 1.5rem' }}><PenTool className="w-8 h-8" /></div>
        <h3>UI/UX Design</h3>
        <p>Prototyping beautiful interfaces with Figma and delivering premium user experiences.</p>
      </motion.div>
      <motion.div className="project-card glass-panel text-center h-full flex flex-col" whileHover={{ y: -10 }}>
        <div className="project-icon" style={{ margin: '0 auto 1.5rem' }}><Database className="w-8 h-8" /></div>
        <h3>Backend Solutions</h3>
        <p>Designing robust databases and RESTful APIs using PHP, MySQL, and modern backend patterns.</p>
      </motion.div>
    </div>
  </section>
);

export default function App() {
  const [theme, setTheme] = useState('dark');

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  return (
    <div className="app-wrapper">
      <CustomCursor />
      <Navbar theme={theme} toggleTheme={toggleTheme} />
      <Hero />
      <About />
      <Services />
      <Education />
      <Skills />
      <Projects />
      <Experience />
      <Contact />
      <Footer />
      <BackToTop />
    </div>
  );
}
